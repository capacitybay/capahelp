const router = require("express").Router();
const jwt = require("jsonwebtoken");

module.exports = { jwt, router };
