const envVariable = require("dotenv");

module.exports = envVariable;
